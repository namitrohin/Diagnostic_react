import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import {
  getUserFilterList,
  getUserRightList,
  setSelectedMenu,
} from "../_redux/actions/common.action";
import { CommonController } from "../_redux/controller/common.controller";
import MainBar from "./appbar";
import MainMenu from "./main_menu";
import Submenu from "./sub_menu";
const Header = ({ onHeaderClick }) => {
  const dispatch = useDispatch();
  const [userRightListArr, setUserRightList] = useState([]);
  const getuserRightListResponse = useSelector(
    (state) => state.common.userRightList
  );

  const [subMenuList, setSubMenuList] = useState([]);
  // const [subMenuList, setsubMenuList] = useState([])
  const [selectedItems, setSelectedItems] = useState({
    main: null,
    subMenu: null,
  });

  const profileTransaction = [
    {
      transaction_id: "",
      transaction_name: "Profile",
      edit_button: "True",
      view_right: "True",
      insert_right: "True",
      update_right: "True",
      delete_right: "True",
      print_right: "True",
    },
    {
      transaction_id: "",
      transaction_name: "Change Password",
      edit_button: "True",
      view_right: "True",
      insert_right: "True",
      update_right: "True",
      delete_right: "True",
      print_right: "True",
    },
    {
      transaction_id: "",
      transaction_name: "Attendance",
      edit_button: "True",
      view_right: "True",
      insert_right: "True",
      update_right: "True",
      delete_right: "True",
      print_right: "True",
    },

    {
      transaction_id: "",
      transaction_name: "Leaves",
      edit_button: "True",
      view_right: "True",
      insert_right: "True",
      update_right: "True",
      delete_right: "True",
      print_right: "True",
    },
    {
      transaction_id: "",
      transaction_name: "Claims",
      edit_button: "True",
      view_right: "True",
      insert_right: "True",
      update_right: "True",
      delete_right: "True",
      print_right: "True",
    },
    {
      transaction_id: "",
      transaction_name: "Ledger",
      edit_button: "True",
      view_right: "True",
      insert_right: "True",
      update_right: "True",
      delete_right: "True",
      print_right: "True",
    },
    {
      transaction_id: "",
      transaction_name: "Cash Entry",
      edit_button: "True",
      view_right: "True",
      insert_right: "True",
      update_right: "True",
      delete_right: "True",
      print_right: "True",
    },
    {
      transaction_id: "",
      transaction_name: "DPR",
      edit_button: "True",
      view_right: "True",
      insert_right: "True",
      update_right: "True",
      delete_right: "True",
      print_right: "True",
    },
  ];

  const getSubMenu = async (menu_id) => {
    try {
     let user_id={user_id:localStorage.getItem("userId")};
      await CommonController.commonApiCallFilter(
        "menu/sublist?menu_id=" +menu_id ,
        user_id,
        "post",
        "node"
      ).then((data) => {
        if (data.status === 200) {
        setSubMenuList(data.data)
        }
      }).catch(err=>{
        // showErrorToast(err.message)
        
      })
    } catch (err) {
      // showErrorToast(err);
    }
  };
  useEffect(() => {
    dispatch(getUserRightList());
    // dispatch(getUserFilterList());
  }, []);

  const groupBy = (array, key) => {
    // Return the end result
    return array.reduce((result, currentValue) => {
      // If an array already present for key, push it to the array. Else create an array and push the object
      (result[currentValue[key]] = result[currentValue[key]] || []).push(
        currentValue
      );
      // Return the current iteration `result` value, this will be taken as next iteration `result` value and accumulate
      return result;
    }, {}); // empty object is the initial value for result object
  };

  useEffect(() => {
    // getSubMenu(75)
    if (getuserRightListResponse.data?.length > 0) {
      // const groupedMenu = groupBy(getuserRightListResponse, "group_name");

       setUserRightList(getuserRightListResponse.data);
    }
  }, [getuserRightListResponse]);

  const handleMenuChange = (id) => {
    var tempMenuIndex = userRightListArr.findIndex((x) => x.menu_id === id);
      if (userRightListArr[tempMenuIndex].menu_name !== "Profile") {
        getSubMenu(id)
        // setSubMenuList(userRightListArr[tempMenuIndex].transaction_lst);
      } else {
        setSubMenuList(profileTransaction);
        // getSubMenu()
      }
    
  };

  return (
    <React.Fragment>
      <MainBar onMenuClick={() => onHeaderClick()} />
      <MainMenu list={userRightListArr} onMenuChange={handleMenuChange} />
      {subMenuList.length > 0 ? <Submenu list={subMenuList} /> : null}
    </React.Fragment>
  );
};

export default Header;
