import React from "react";
import loaderImg from "../assets/image/loader.gif";

export const Loader = () => {
  return "";
  // <div className="custom-loading">
  //   <div>
  //     <img src={loaderImg} />
  //     {/* <Cu */}
  //     <p>Please wait...</p>
  //   </div>
  // </div>
};
