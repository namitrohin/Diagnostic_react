module.exports = {
  baseUrl: "https://diagapi.quickgst.in/",
  apiUrl: "https://diagapi.quickgst.in/api/",
  // nodeUrl: "https://diagnodeapi.quickgst.in/",
  nodeUrl: "http://localhost:4000/",
  jsonUrl: "http://localhost:9000/",

  // baseUrl:'http://admin.mistletoe.co.in/',
  // apiUrl:'http://admin.mistletoe.co.in/api/'
};
