import React from 'react'
import ActionButtons from '../../../../components/action-buttons'

export default function ChallanIndexSlWip() {
    const handleDelete=(e)=>{console.log(e)}
  return (
    <div>
      <p>-----------SlWip----------</p>
      <ActionButtons onDelete={handleDelete} />
    </div>
  )
}
