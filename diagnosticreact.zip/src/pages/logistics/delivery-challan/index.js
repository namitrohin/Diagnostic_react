import React, { useState } from "react";

import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import ChallanIndexMdc from "./mdc";
import ChallanIndexSlWip from "./slwip";

import ChallanIndex from "./subIndex";

const DeliveryChallanIndex = () => {
  const challanType = new URLSearchParams(window.location.search).get("type");
  const [index, setindex] = useState(0)
  const history = useHistory();
  // console.log(challanType);

  return (
    <div className="card card-custom gutter-b  px-7 py-3">
      <ul className="nav nav-tabs nav-tabs-line">
        <li className="nav-item">
          <a
            className={
              `nav-link ` +
              (index === 0
                ? "active"
                : "")
            }
            onClick={() => {
              // window.location.href = `/logistics/delivery-challan?type=${encodeURIComponent(
              //   "SL" 
              // )}`;
              setindex(0)
            }}
          >
            SL DC
          </a>
        </li>
        <li className="nav-item">
          <a
            className={
              `nav-link ` +
              (index === 1 ? "active" : "")
            }
            onClick={() =>
              // (window.location.href = `/logistics/delivery-challan?type=${encodeURIComponent(
              //   "Non SL"
              // )}`)
              setindex(1)
            }
          >
            Non SL DC
          </a>
        </li>
        <li className="nav-item">
          <a
            className={
              `nav-link ` +
              (index === 2? "active" : "")
            }
            onClick={() =>
              // (window.location.href = `/logistics/delivery-challan?type=${encodeURIComponent(
              //   "MDC"
              // )}`)
              setindex(2)
            }
          >
            MDC
          </a>
        </li>
        <li className="nav-item">
          <a
            className={
              `nav-link ` +
              (index === 3? "active" : "")
            }
            onClick={() =>
              // (window.location.href = `/logistics/delivery-challan?type=${encodeURIComponent(
              //   "MDC"
              // )}`)
              setindex(3)
            }
          >
            SL WIP
          </a>
        </li>
        <li className="nav-item">
          <a
            className={
              `nav-link ` +
              (index === 4? "active" : "")
            }
            onClick={() =>
              // (window.location.href = `/logistics/delivery-challan?type=${encodeURIComponent(
              //   "MDC"
              // )}`)
              setindex(4)
            }
          >
            Non SL WIP
          </a>
        </li>
        
      </ul>
      <div className="tab-content">
       {(index===0||index===1 )&&<ChallanIndex
          type={challanType ? decodeURIComponent(challanType) : "SL"}
        />}
        {index===2&& <ChallanIndexMdc/>}
        {(index===3 ||index===4)&&<ChallanIndexSlWip/>}
      </div>
    </div>
  );
};

export default DeliveryChallanIndex;
