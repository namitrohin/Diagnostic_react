import React from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import AccountsMaster from "../pages/Master/Accounts_Master/index";
import ComboMLFBIndex from "../pages/Master/combomlfb";
import ConfigurationMaster from "../pages/Master/Configuration";
import EmployeeIndex from "../pages/Master/employee";
import GodownIndex from "../pages/Master/godown";
import GodownBrowse from "../pages/Master/godown/browse";
import ItemGroupIndex from "../pages/Master/item Group";
import MaterialCodeIndex from "../pages/Master/Material Code";
import ProductMasterIndex from "../pages/Master/Product";
import UserRightList from "../pages/Master/user rights/browse";

const Masters = () => {
  return (
    <div className="container-fluid">
      <Switch>
        <Route
          path="/masters/account-master"
          exact
          component={AccountsMaster}
        />
        <Route
          path="/masters/configuration-master"
          exact
          component={ConfigurationMaster}
        />
        <Route
          path="/masters/product-master"
          exact
          component={ProductMasterIndex}
        />
        <Route
          path="/masters/material-code"
          exact
          component={MaterialCodeIndex}
        />
        <Route
          path="/masters/item-group-master"
          exact
          component={ItemGroupIndex}
        />
        <Route path="/masters/combined-mlfb" exact component={ComboMLFBIndex} />
        <Route path="/masters/godown-master" exact component={GodownIndex} />
        <Route path="/masters/user-right" exact component={UserRightList} />
        <Route
          path="/masters/employee-master"
          exact
          component={EmployeeIndex}
        />
        <Redirect to="/masters/account-master" from="/masters" />
      </Switch>
    </div>
  );
};

export default Masters;
