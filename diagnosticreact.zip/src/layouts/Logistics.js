import React from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import DCIndex from "../pages/DC";
import DeliveryChallanIndex from "../pages/logistics/delivery-challan";

import DeliveryChallanBrowse from "../pages/logistics/delivery-challan/browse";

const Logistics = () => {
  return (
    <div className="container-fluid">
      <Switch>
        <Route path="/logistics/dc-packaging" exact component={DCIndex} />
        <Route
          path="/logistics/delivery-challan"
          exact
          component={DeliveryChallanIndex}
        />

        <Redirect to="/logistics/dc-packaging" from="/logistics" />
      </Switch>
    </div>
  );
};

export default Logistics;
