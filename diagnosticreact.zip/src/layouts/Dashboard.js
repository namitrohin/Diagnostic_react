import React from 'react';


const Dashboard = () => {
    return(
    <React.Fragment>
              hello dashboard
    </React.Fragment>
          
    )
}

export default Dashboard;